package elektryk.sawicki.jakub.polimorfizm2.Random.slowo;

public class Inne implements SlowoImp{
    @Override
    public String Wspak() {
        return null;
    }

    @Override
    public String Samo() {
        return null;
    }

    @Override
    public String Wspol() {
        return null;
    }
}
