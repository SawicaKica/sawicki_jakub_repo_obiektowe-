package elektryk.sawicki.jakub.polimorfizm2.Random.slowo;

public interface SlowoImp {
    String Wspak();
    String Samo();
    String Wspol();
}
