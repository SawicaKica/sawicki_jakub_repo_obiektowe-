package elektryk.sawicki.jakub.polimorfizm2.Random;

public interface imp {
    String SaveArray();
    String SaveList();
}
