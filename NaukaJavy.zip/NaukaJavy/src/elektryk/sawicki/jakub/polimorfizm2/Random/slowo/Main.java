package elektryk.sawicki.jakub.polimorfizm2.Random.slowo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Podaj wyraz: ");
        String wyraz = sc.nextLine();


    }
}
