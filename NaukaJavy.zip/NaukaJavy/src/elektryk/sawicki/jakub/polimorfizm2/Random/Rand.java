package elektryk.sawicki.jakub.polimorfizm2.Random;
import elektryk.sawicki.jakub.polimorfizm2.Random.imp;

import java.util.ArrayList;
import java.util.Random;

public class Rand implements imp {
    @Override
    public String SaveArray() {
        Random r = new Random();
        int[] tab = new int[15];
        String s = new String();
        for(int i=0;i<15;i++){
            tab[i] = r.nextInt(9)+1;
        }
        for(int i=0;i<15;i++){
            s+=" "+tab[i];
        }
        return s;
    }

    @Override
    public String SaveList() {
        ArrayList list = new ArrayList(15);
        String s = "";
        Random r = new Random();
        for(int i=0;i<15;i++){
            list.add(i, r.nextInt(9)+1);
        }
        for(int i=0;i<15;i++){
            s+=" "+list.get(i);
    }
        return s;

    }
}
