package elektryk.sawicki.jakub.polimorfizm2.Random;

import java.util.Scanner;

public class Main{
    public static void main(String[] args) {
        imp l = new Rand();
        Scanner sc = new Scanner(System.in);
        System.out.println("Losowe liczby chce zapisac w: [1 - Tablicy] [2 - Listy]");
        int wybor = sc.nextInt();

        if(wybor == 1){
            System.out.println(l.SaveArray());
        }else if(wybor == 2){
            System.out.println(l.SaveList());
        }else{
            System.out.println("Wprowadziles zla liczbe");
        }
    }

}
