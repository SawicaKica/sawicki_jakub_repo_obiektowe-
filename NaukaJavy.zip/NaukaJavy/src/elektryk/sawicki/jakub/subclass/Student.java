package elektryk.sawicki.jakub.subclass;

public class Student extends Person{
    private String fieldOfStudy;

    public Student(int height, int weight, String fieldOfStudy) {
        this.setHeight(height);
        this.setWeight(weight);
        this.fieldOfStudy = fieldOfStudy;
    }

    public Student() {
    }

    public String getFieldOfStudy() {
        return fieldOfStudy;
    }

    public void setFieldOfStudy(String fieldOfStudy) {
        this.fieldOfStudy = fieldOfStudy;
    }

    @Override
    public String toString() {
        return "Student{" +
                "height=" + getHeight() +
                ", weight=" + getWeight() +
                ", fieldOfStudy='" + fieldOfStudy + '\'' +
                '}';
    }
}
