package elektryk.sawicki.jakub.subclass;

public class Main {
    public static void main(String[] args) {
        Student s1 = new Student(185, 70, "Informatyka");
        Student s2 = new Student();
        Teacher t1 = new Teacher(170, 60,"Doktor");
        System.out.println("Student; \nwzrost: "+s1.getHeight()+"\nwaga: "+s1.getWeight()+"\nkierunek: "+s1.getFieldOfStudy()+"\n");
        System.out.println("Teacher: \nwzrost: "+t1.getHeight()+"\nwaga: "+t1.getWeight()+"\nstopien naukowy: "+t1.getDegree());
    }
}
