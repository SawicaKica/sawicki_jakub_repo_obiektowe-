package elektryk.sawicki.jakub.subclass;

public class Teacher extends Person{
    private String degree;

    public Teacher(int height, int weight, String degree) {
        this.setHeight(height);
        this.setWeight(weight);
        this.degree = degree;
    }

    public Teacher() {
    }


    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "height=" + getHeight() +
                ", weight=" + getWeight() +
                ", degree='" + degree + '\'' +
                '}';
    }
}
