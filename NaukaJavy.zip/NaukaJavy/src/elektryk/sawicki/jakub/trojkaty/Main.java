package elektryk.sawicki.jakub.trojkaty;

import java.math.BigDecimal;
public class Main{
    public static void main(String[] args) {
        AreaOfTheTriangle aott = new AreaOfTheTriangle();
        System.out.println(aott.area(new BigDecimal("3"), new BigDecimal("4")));
        System.out.println(aott.area(new BigDecimal("2"),new BigDecimal("3"),new BigDecimal("4"),new BigDecimal("2")));
        System.out.println(aott.area(new BigDecimal("4"),new BigDecimal("2"),new BigDecimal("5"),new BigDecimal("3")));
    }
}
