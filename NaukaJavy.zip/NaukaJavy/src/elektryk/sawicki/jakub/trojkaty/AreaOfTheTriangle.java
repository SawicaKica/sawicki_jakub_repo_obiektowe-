package elektryk.sawicki.jakub.trojkaty;

import java.math.BigDecimal;
import java.math.MathContext;

public class AreaOfTheTriangle {
    private BigDecimal wynik = new BigDecimal("1");
    private MathContext mc = new MathContext(10);

    public BigDecimal area(BigDecimal a, BigDecimal h) {
        BigDecimal dwa = new BigDecimal("2");
        wynik = wynik.multiply(a);
        wynik = wynik.multiply(h);
        wynik = wynik.divide(dwa);
        return wynik;
    }

    public BigDecimal area(BigDecimal r, BigDecimal a, BigDecimal b, BigDecimal c) {
        BigDecimal cztery = new BigDecimal("4");
        wynik = wynik.multiply(a);
        wynik = wynik.multiply(b);
        wynik = wynik.multiply(c);
        cztery = cztery.multiply(r);
        wynik = wynik.divide(cztery);
        return wynik;
    }

    public BigDecimal area(BigDecimal r, BigDecimal a, BigDecimal b, BigDecimal c, boolean zero) {
        BigDecimal dwa = new BigDecimal("2");
        wynik = wynik.multiply(a);
        wynik = wynik.multiply(b);
        wynik = wynik.multiply(c);
        wynik = wynik.divide(dwa);
        wynik = wynik.multiply(r);
        return wynik;
    }
}

