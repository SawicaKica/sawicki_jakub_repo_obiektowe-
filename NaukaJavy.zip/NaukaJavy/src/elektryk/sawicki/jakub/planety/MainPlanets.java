package elektryk.sawicki.jakub.planety;

import java.util.Scanner;

public class MainPlanets {
    public static void main(String[] args) {

        PlanetImp planetImp;

        System.out.println("Wybierz planete: 1-[Ziemia] 2-[Mars] 3-[Wenus] 4-[Jowisz] 5-[Saturn] 6-[Neptun] 7-[Merkury] 8-[Uran]");
        Scanner sc = new Scanner(System.in);
        int nrp = sc.nextInt();

        if(nrp == 1){
            planetImp = new Earth(true, true, "Ziemia");
        }else if(nrp == 2){
            planetImp = new Mars(false, true, "Mars");
        }else if(nrp == 3){
            planetImp = new Wenus(false, false, "Wenus");
        }else if(nrp == 4){
            planetImp = new Jowisz(false, false, "Jowisz");
        }else if(nrp == 5){
            planetImp = new Saturn(false, false, "Saturn");
        }else if(nrp == 6){
            planetImp = new Neptun(false, false, "Neptun");
        }else if(nrp == 7){
            planetImp = new Merkury(false, false, "Merkury");
        }else if(nrp == 8){
            planetImp = new Uran(false, false, "Uran");
        }else{
            planetImp = null;
            System.out.println("WYbrano zla planete");
        }


        if(planetImp != null) {
            System.out.println("Czy ma zycie "+planetImp.isLife()+
                    "\n Czy ma atmosfere "+planetImp.isAtmosphere()+
                    "\n Nazwa: "+planetImp.getNamePlanet());
        }

    }
}
