package elektryk.sawicki.jakub.planety;

public interface PlanetImp {
    boolean isLife();
    boolean isAtmosphere();
    String getNamePlanet();
}
