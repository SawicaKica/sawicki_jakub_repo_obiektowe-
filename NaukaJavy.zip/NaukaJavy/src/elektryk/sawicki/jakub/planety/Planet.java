package elektryk.sawicki.jakub.planety;

public class Planet {
    private boolean isLife;
    private  boolean isAtmosphere;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getLife() {
        return isLife;
    }

    public void setLife(boolean life) {
        isLife = life;
    }

    public boolean getAtmosphere() {
        return isAtmosphere;
    }

    public void setAtmosphere(boolean atmosphere) {
        isAtmosphere = atmosphere;
    }

}
