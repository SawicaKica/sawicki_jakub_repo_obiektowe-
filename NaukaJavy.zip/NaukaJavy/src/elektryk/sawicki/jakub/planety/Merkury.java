package elektryk.sawicki.jakub.planety;

public class Merkury extends Planet implements PlanetImp{

    public Merkury(boolean isLife, boolean isAtmosphere, String name){
        setLife(isLife);
        setAtmosphere(isAtmosphere);
        setName(name);
    }

    @Override
    public boolean isLife() {
        return getLife();
    }

    @Override
    public boolean isAtmosphere() {
        return getAtmosphere();
    }

    @Override
    public String getNamePlanet() {
        return getName();
    }
}
