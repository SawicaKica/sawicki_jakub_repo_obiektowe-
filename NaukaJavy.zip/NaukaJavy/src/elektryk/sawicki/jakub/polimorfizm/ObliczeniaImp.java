package elektryk.sawicki.jakub.polimorfizm;

public interface ObliczeniaImp {
    double oblicz(double l1, double l2);
}
