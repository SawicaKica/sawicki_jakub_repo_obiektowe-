package elektryk.sawicki.jakub.polimorfizm;

import java.util.Scanner;

public class Kalkulator {
    public static void main(String[] args) {

        ObliczeniaImp imp;

        System.out.println("Wybierz dzialanie: [+][-][/][*]");
        Scanner sc = new Scanner(System.in);
        String sign = sc.next();

        if(sign.equals("+")){
            imp = new Suma();
        }else if(sign.equals("-")){
            imp = new Roznica();
        }else if(sign.equals("/")){
            imp = new Iloraz();
        }else if(sign.equals("*")){
            imp = new Iloczyn();
        }else{
            System.out.println("");
        }
    }
}
