package elektryk.sawicki.jakub.polimorfizm;

public class Iloczyn implements ObliczeniaImp{

    @Override
    public double oblicz(double l1, double l2) {
        return l1*l2;
    }
}
